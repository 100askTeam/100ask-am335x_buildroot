var menudata={children:[
{text:"Main Page",url:"index.html"},
{text:"Modules",url:"modules.html"},
{text:"Data Structures",url:"annotated.html",children:[
{text:"Data Structures",url:"annotated.html"},
{text:"Data Fields",url:"functions.html",children:[
{text:"All",url:"functions.html"},
{text:"Variables",url:"functions_vars.html"}]}]},
{text:"Examples",url:"examples.html"}]}
